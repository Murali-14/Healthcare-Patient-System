const mongoose = require('mongoose');

const patientSchema = new mongoose.Schema({
  patientId: { type: String, required: true, unique: true },
  name: String,
  age: Number,
  gender: String,
  contactInfo: {
    phone: String,
    email: String,
    address: String
  },
  allergies: [String],
  medicalHistory: [String],
  prescriptions: [String],
  doctorNotes: String,
  visitDates: [Date]
}, { timestamps: true });

module.exports = mongoose.model('Patient', patientSchema);