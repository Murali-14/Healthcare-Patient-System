const express = require('express');
const router = express.Router();
const Patient = require('../models/Patient');

router.post('/', async (req, res) => {
  try {
    const patient = new Patient(req.body);
    await patient.save();
    res.status(201).send(patient);
  } catch (err) {
    res.status(400).send(err);
  }
});

router.get('/search', async (req, res) => {
  const { name, patientId } = req.query;
  const query = {};
  if (name) query.name = { $regex: name, $options: 'i' };
  if (patientId) query.patientId = patientId;
  const patients = await Patient.find(query).limit(20);
  res.send(patients);
});

router.put('/:id', async (req, res) => {
  try {
    const patient = await Patient.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.send(patient);
  } catch (err) {
    res.status(400).send(err);
  }
});

router.delete('/:id', async (req, res) => {
  try {
    await Patient.findByIdAndDelete(req.params.id);
    res.send({ message: 'Deleted' });
  } catch (err) {
    res.status(500).send(err);
  }
});

module.exports = router;