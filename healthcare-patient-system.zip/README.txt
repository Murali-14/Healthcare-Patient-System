# Healthcare Patient Management System

## Setup Instructions

### Backend
1. Go to backend folder:
   cd backend
2. Install dependencies:
   npm install
3. Create .env file and paste your MongoDB Atlas connection URI.
4. Run the server:
   node app.js

### Frontend
1. Go to frontend folder:
   cd frontend
2. Create React App if not already:
   npx create-react-app .
3. Install Axios:
   npm install axios
4. Replace src/App.js with the provided one.
5. Start React App:
   npm start

### MongoDB
- Use MongoDB Atlas or local MongoDB
- Use MongoDB Compass to visualize data in the patients collection