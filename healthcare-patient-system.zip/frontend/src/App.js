import React, { useState, useEffect } from 'react';
import axios from 'axios';

function App() {
  const [patients, setPatients] = useState([]);
  const [form, setForm] = useState({
    patientId: '', name: '', age: '', gender: '',
    contactInfo: { phone: '', email: '', address: '' },
    allergies: '', medicalHistory: '', prescriptions: '', doctorNotes: ''
  });

  const fetchPatients = async () => {
    const res = await axios.get('http://localhost:5000/api/patients/search');
    setPatients(res.data);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name.includes('contactInfo.')) {
      const field = name.split('.')[1];
      setForm(prev => ({ ...prev, contactInfo: { ...prev.contactInfo, [field]: value } }));
    } else {
      setForm(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const payload = {
      ...form,
      age: parseInt(form.age),
      allergies: form.allergies.split(','),
      medicalHistory: form.medicalHistory.split(','),
      prescriptions: form.prescriptions.split(',')
    };
    await axios.post('http://localhost:5000/api/patients', payload);
    fetchPatients();
  };

  const handleDelete = async (id) => {
    await axios.delete(`http://localhost:5000/api/patients/${id}`);
    fetchPatients();
  };

  useEffect(() => { fetchPatients(); }, []);

  return (
    <div style={{ padding: '20px' }}>
      <h2>Healthcare Patient Management</h2>
      <form onSubmit={handleSubmit}>
        <input name="patientId" placeholder="Patient ID" onChange={handleChange} /><br />
        <input name="name" placeholder="Name" onChange={handleChange} /><br />
        <input name="age" type="number" placeholder="Age" onChange={handleChange} /><br />
        <input name="gender" placeholder="Gender" onChange={handleChange} /><br />
        <input name="contactInfo.phone" placeholder="Phone" onChange={handleChange} /><br />
        <input name="contactInfo.email" placeholder="Email" onChange={handleChange} /><br />
        <input name="contactInfo.address" placeholder="Address" onChange={handleChange} /><br />
        <input name="allergies" placeholder="Allergies (comma separated)" onChange={handleChange} /><br />
        <input name="medicalHistory" placeholder="Medical History (comma separated)" onChange={handleChange} /><br />
        <input name="prescriptions" placeholder="Prescriptions (comma separated)" onChange={handleChange} /><br />
        <input name="doctorNotes" placeholder="Doctor Notes" onChange={handleChange} /><br />
        <button type="submit">Add Patient</button>
      </form>

      <h3>Patients</h3>
      {patients.map(p => (
        <div key={p._id}>
          {p.name} - {p.age} yrs - ID: {p.patientId}
          <button onClick={() => handleDelete(p._id)}>Delete</button>
        </div>
      ))}
    </div>
  );
}

export default App;